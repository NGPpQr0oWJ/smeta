from flask import Flask, render_template, request, redirect, url_for, session, send_from_directory, jsonify
import sqlite3
import pandas as pd
from datetime import datetime
import os
import pandas as pd

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
MATERIALS_PATH = os.path.join('database', 'materials.xlsx')

def load_materials():
    """Загрузка материалов из Excel."""
    try:
        materials_data = pd.read_excel(MATERIALS_PATH)
        return materials_data
    except FileNotFoundError:
        print(f"Файл {MATERIALS_PATH} не найден.")
        return pd.DataFrame()

materials_data = load_materials()

def init_db():
    """Инициализация базы данных."""
    conn = sqlite3.connect('tech_map.db')
    cursor = conn.cursor()

    # Таблица пользователей
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL
        )
    ''')

    # Таблица продуктов
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            order_number TEXT NOT NULL,
            creation_date TEXT NOT NULL,
            project_file TEXT
        )
    ''')

    # Таблица материалов
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS materials (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL,
            article TEXT,
            name TEXT NOT NULL,
            quantity TEXT,
            unit TEXT,
            notes TEXT,
            FOREIGN KEY(product_id) REFERENCES products(id)
        )
    ''')

    # Добавляем администратора
    cursor.execute('''
        INSERT OR IGNORE INTO users (username, password)
        VALUES ('admin', 'admin')
    ''')

    conn.commit()
    conn.close()

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Страница авторизации пользователя."""
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = sqlite3.connect('tech_map.db')
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE username = ? AND password = ?', (username, password))
        user = cursor.fetchone()
        conn.close()
        if user:
            session['user_id'] = user[0]
            session['username'] = user[1]
            return redirect(url_for('index'))
        else:
            return render_template('login.html', error='Неверное имя пользователя или пароль')
    return render_template('login.html')

@app.route('/logout')
def logout():
    """Выход пользователя."""
    session.pop('user_id', None)
    session.pop('username', None)
    return redirect(url_for('login'))

@app.route('/add_user', methods=['GET', 'POST'])
def add_user():
    """Добавление нового пользователя администратором."""
    if 'user_id' not in session or session.get('username') != 'admin':
        return redirect(url_for('login'))
    if request.method == 'POST':
        fio = request.form['fio']
        username = request.form['username']
        password = request.form['password']
        conn = sqlite3.connect('tech_map.db')
        cursor = conn.cursor()
        try:
            cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, password))
            conn.commit()
            conn.close()
            return redirect(url_for('index'))
        except sqlite3.IntegrityError:
            conn.close()
            return render_template('add_user.html', error='Имя пользователя уже занято')
    return render_template('add_user.html')

@app.route('/')
def index():
    """Главная страница: список всех продуктов."""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    is_admin = session.get('username') == 'admin'
    search_query = request.args.get('search', '')
    sort_by_date = request.args.get('sort_by_date', '')

    conn = sqlite3.connect('tech_map.db')
    cursor = conn.cursor()

    if search_query:
        cursor.execute('''
            SELECT * FROM products
            WHERE name LIKE ? OR order_number LIKE ?
            ORDER BY creation_date DESC
        ''', (f'%{search_query}%', f'%{search_query}%'))
    else:
        cursor.execute('SELECT * FROM products ORDER BY creation_date DESC' if sort_by_date else 'SELECT * FROM products')

    products = cursor.fetchall()
    conn.close()

    return render_template('index.html', products=products, is_admin=is_admin, search_query=search_query, sort_by_date=sort_by_date)

@app.route('/product/<int:product_id>')
def product_details(product_id):
    """Детали продукта: список материалов."""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    conn = sqlite3.connect('tech_map.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM products WHERE id = ?', (product_id,))
    product = cursor.fetchone()
    cursor.execute('SELECT * FROM materials WHERE product_id = ?', (product_id,))
    materials = cursor.fetchall()
    conn.close()
    return render_template('product_details.html', product=product, materials=materials)

@app.route('/delete_product/<int:product_id>', methods=['POST'])
def delete_product(product_id):
    """Удаление продукта."""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    conn = sqlite3.connect('tech_map.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM products WHERE id = ?', (product_id,))
    cursor.execute('DELETE FROM materials WHERE product_id = ?', (product_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

@app.route('/add_product', methods=['GET', 'POST'])
def add_product():
    """Добавление нового продукта."""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    if request.method == 'POST':
        name = request.form['name']
        order_number = request.form['order_number']
        creation_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        project_file = None
        if 'project_file' in request.files:
            file = request.files['project_file']
            if file and file.filename != '' and file.content_length <= 100 * 1024 * 1024:
                project_file = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
                file.save(project_file)
        conn = sqlite3.connect('tech_map.db')
        cursor = conn.cursor()
        cursor.execute('INSERT INTO products (name, order_number, creation_date, project_file) VALUES (?, ?, ?, ?)', (name, order_number, creation_date, project_file))
        conn.commit()
        conn.close()
        return redirect(url_for('index'))
    return render_template('add_product.html', datetime=datetime)

@app.route('/download_project/<int:product_id>')
def download_project(product_id):
    """Скачивание проектной документации."""
    conn = sqlite3.connect('tech_map.db')
    cursor = conn.cursor()
    cursor.execute('SELECT project_file FROM products WHERE id = ?', (product_id,))
    project_file = cursor.fetchone()[0]
    conn.close()
    if project_file and os.path.exists(project_file):
        return send_from_directory(app.config['UPLOAD_FOLDER'], os.path.basename(project_file), as_attachment=True)
    return redirect(request.referrer)

@app.route('/add_material/<int:product_id>', methods=['POST'])
def add_material(product_id):
    """Добавление материала к продукту."""
    if 'user_id' not in session:
        return redirect(url_for('login'))

    material = request.form.get('material')
    article = request.form.get('article')
    unit = request.form.get('unit')
    quantity = request.form.get('quantity')
    notes = request.form.get('notes')

    # Проверяем, что обязательные поля заполнены
    if not material or not quantity:
        return redirect(url_for('product_details', product_id=product_id))

    # Добавляем материал в базу данных
    conn = sqlite3.connect('tech_map.db')
    cursor = conn.cursor()
    cursor.execute(
        'INSERT INTO materials (product_id, name, article, quantity, unit, notes) VALUES (?, ?, ?, ?, ?, ?)',
        (product_id, material, article, quantity, unit, notes)
    )
    conn.commit()
    conn.close()
    return redirect(url_for('product_details', product_id=product_id))

@app.route('/delete_material/<int:material_id>', methods=['POST'])
def delete_material(material_id):
    """Удаление материала."""
    if 'user_id' not in session:
        return redirect(url_for('login'))
    conn = sqlite3.connect('tech_map.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM materials WHERE id = ?', (material_id,))
    conn.commit()
    conn.close()
    return redirect(request.referrer)

@app.route('/search_material', methods=['GET'])
def search_material():
    """Поиск материала по названию."""
    query = request.args.get('q', '').lower()
    if not query:
        return jsonify([])

    # Фильтруем материалы
    filtered = materials_data[materials_data['Материал'].str.contains(query, case=False, na=False)]
    results = filtered[['Артикул', 'Материал', 'Ед. изм.']].head(10).to_dict(orient='records')

    return jsonify(results)


if __name__ == '__main__':
    init_db()  # Инициализация базы данных перед запуском приложения
    app.run(debug=True)
